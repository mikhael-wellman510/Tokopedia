package com.enigma.tokopedia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TokopediaApplicationTests {

	@Test
	void contextLoads() {
	}

}
